"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║         A++  —  Plain-English Programming Language           ║
║         Version   :  0.6  Prototype                          ║
║         Started   :  21 / 04 / 2026                          ║
║         Updated   :  22 / 04 / 2026                          ║
║                                                              ║
║         "Code in the language you already speak."            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""

# ══════════════════════════════════════════════════════════════════
#  STANDARD IMPORTS
# ══════════════════════════════════════════════════════════════════

import sys
import re
import difflib
import traceback
import os
import sqlite3
import threading
import datetime
from collections import deque

# ══════════════════════════════════════════════════════════════════
#  LOGGING
# ══════════════════════════════════════════════════════════════════

def _info(msg: str) -> None: print(f"  💡 {msg}")
def _warn(msg: str) -> None: print(f"  ⚠️  {msg}")
def _err (msg: str) -> None: print(f"  ❌ {msg}")


# ══════════════════════════════════════════════════════════════════
#  OPERATOR TABLES  (English ↔ Symbol, both always work)
# ══════════════════════════════════════════════════════════════════

RELATIONAL_OPS: list[tuple[str, str]] = [
    ("is greater than or equal to",  ">="),
    ("is less than or equal to",     "<="),
    ("is not equal to",              "!="),
    ("is greater than",              ">" ),
    ("is less than",                 "<" ),
    ("is equal to",                  "=="),
    (">=", ">="), ("<=", "<="), ("!=", "!="),
    (">",  ">" ), ("<",  "<" ), ("==", "=="),
]

ARITHMETIC_OPS: list[tuple[str, str]] = [
    ("to the power of",   "**"),
    ("floor divided by",  "//"),
    ("divided by",        "/" ),
    ("plus",              "+" ),
    ("minus",             "-" ),
    ("modulo",            "%" ),
    ("mod",               "%" ),
    ("**", "**"), ("//", "//"),
    ("/",  "/" ), ("+",  "+" ), ("-", "-"), ("%", "%"),
]

LOGICAL_OPS: list[tuple[str, str]] = [
    ("and also", "and"), ("or else",  "or"),
    ("and", "and"), ("or", "or"), ("not", "not"),
    ("&&", "and"), ("||", "or"),
]

MEMBERSHIP_OPS: list[tuple[str, str]] = [
    ("is not in", "not in"), ("is in", "in"),
    ("not in", "not in"),    ("in",    "in"),
]

BOOL_LITERALS: list[tuple[str, str]] = [
    ("is true", "== True"), ("is false", "== False"),
    ("is nothing", "is None"), ("is null", "is None"),
    ("true", "True"), ("false", "False"),
    ("nothing", "None"), ("null", "None"),
]

ALL_OPS: list[tuple[str, str]] = (
    RELATIONAL_OPS + ARITHMETIC_OPS + LOGICAL_OPS +
    MEMBERSHIP_OPS + BOOL_LITERALS
)

OPERATOR_REFERENCE = """
  ── RELATIONAL  (English or Symbol) ──────────────────────────────
    is equal to                        ==
    is not equal to                    !=
    is greater than                     >
    is less than                        <
    is greater than or equal to        >=
    is less than or equal to           <=

  ── ARITHMETIC  (English or Symbol) ──────────────────────────────
    plus +   minus -   divided by /   modulo/mod %
    to the power of **   floor divided by //
    (* works directly — 'times' is reserved for repeat loops)

  ── LOGICAL  (English or Symbol) ─────────────────────────────────
    and / and also  &&    or / or else  ||    not

  ── MEMBERSHIP ───────────────────────────────────────────────────
    x is in list       x in list
    x is not in list   x not in list

  ── BOOLEANS & NULL ──────────────────────────────────────────────
    true  false  nothing/null
    is true   is false   is nothing/is null

  ── AUGMENTED ASSIGNMENT ─────────────────────────────────────────
    increase score by 5   score += 5
    decrease health by 1  health -= 1
    add 3 to total        total += 3
    subtract 2 from total total -= 2
    multiply total by 2   total *= 2
    divide total by 4     total /= 4
"""


# ══════════════════════════════════════════════════════════════════
#  SQLITE MEMORY  —  persistent correction store
# ══════════════════════════════════════════════════════════════════

_DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "iece_memory.db")

_DECAY_DAYS     = 30   # confidence decays after this many days of no use
_AUTO_THRESHOLD = 80   # confidence ≥ this → apply without prompt
_AUTO_SAVE_EVERY = 5   # commit after this many new corrections


class IECEMemory:
    """
    SQLite-backed correction store.
    Schema: corrections(wrong TEXT PK, right TEXT, confidence INT,
                        use_count INT, last_used TEXT, created TEXT)
    """

    def __init__(self, db_path: str = _DB_FILE) -> None:
        self._path    = db_path
        self._pending = 0           # corrections since last commit
        self._conn    = self._open()
        self._migrate()

    # ── lifecycle ────────────────────────────────────────────────

    def _open(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _migrate(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS corrections (
                wrong       TEXT PRIMARY KEY,
                right       TEXT NOT NULL,
                confidence  INTEGER DEFAULT 50,
                use_count   INTEGER DEFAULT 1,
                last_used   TEXT,
                created     TEXT
            )
        """)
        self._conn.commit()

    def close(self) -> None:
        self._conn.commit()
        self._conn.close()

    # ── CRUD ─────────────────────────────────────────────────────

    def get(self, wrong: str) -> dict | None:
        """Return correction row or None."""
        row = self._conn.execute(
            "SELECT * FROM corrections WHERE wrong = ?", (wrong.lower().strip(),)
        ).fetchone()
        return dict(row) if row else None

    def learn(self, wrong: str, right: str, bump_confidence: int = 10) -> None:
        """Insert or update a correction, raising confidence."""
        now   = datetime.datetime.now(datetime.timezone.utc).isoformat()
        key   = wrong.lower().strip()
        existing = self.get(key)
        if existing:
            new_conf = min(100, existing["confidence"] + bump_confidence)
            self._conn.execute("""
                UPDATE corrections
                   SET right = ?, confidence = ?, use_count = use_count + 1, last_used = ?
                 WHERE wrong = ?
            """, (right, new_conf, now, key))
        else:
            self._conn.execute("""
                INSERT INTO corrections (wrong, right, confidence, use_count, last_used, created)
                VALUES (?, ?, 50, 1, ?, ?)
            """, (key, right, now, now))
        self._pending += 1
        if self._pending >= _AUTO_SAVE_EVERY:
            self._conn.commit()
            self._pending = 0

    def reject(self, wrong: str) -> None:
        """Lower confidence when user rejects a suggestion."""
        existing = self.get(wrong)
        if existing:
            new_conf = max(0, existing["confidence"] - 15)
            self._conn.execute(
                "UPDATE corrections SET confidence = ? WHERE wrong = ?",
                (new_conf, wrong.lower().strip())
            )

    def forget(self) -> None:
        """Wipe all corrections."""
        self._conn.execute("DELETE FROM corrections")
        self._conn.commit()

    def sync(self) -> None:
        """Force commit."""
        self._conn.commit()
        self._pending = 0

    def apply_decay(self) -> None:
        """Reduce confidence for corrections unused for _DECAY_DAYS days."""
        cutoff = (datetime.datetime.now(datetime.timezone.utc) -
                  datetime.timedelta(days=_DECAY_DAYS)).isoformat()
        self._conn.execute("""
            UPDATE corrections
               SET confidence = MAX(0, confidence - 20)
             WHERE last_used < ? AND confidence > 0
        """, (cutoff,))
        self._conn.commit()

    def stats(self) -> dict:
        total = self._conn.execute("SELECT COUNT(*) FROM corrections").fetchone()[0]
        high  = self._conn.execute(
            "SELECT COUNT(*) FROM corrections WHERE confidence >= ?",
            (_AUTO_THRESHOLD,)
        ).fetchone()[0]
        top   = self._conn.execute(
            "SELECT wrong, right, use_count FROM corrections ORDER BY use_count DESC LIMIT 5"
        ).fetchall()
        return {"total": total, "high_confidence": high, "top5": [dict(r) for r in top]}

    def all_corrections(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT wrong, right, confidence, use_count FROM corrections ORDER BY wrong"
        ).fetchall()
        return [dict(r) for r in rows]

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def __getitem__(self, key: str) -> str | None:
        row = self.get(key)
        return row["right"] if row else None

    def high_confidence(self, key: str) -> bool:
        row = self.get(key)
        return bool(row and row["confidence"] >= _AUTO_THRESHOLD)


# ══════════════════════════════════════════════════════════════════
#  IECE v3  —  Intelligent Error Correction Engine
# ══════════════════════════════════════════════════════════════════

_KEYWORDS: list[str] = [
    "set", "to", "say", "if", "is", "greater", "than", "less", "equal",
    "then", "else", "repeat", "times", "while", "end", "loop", "each",
    "in", "define", "function", "return", "and", "or", "not", "true",
    "false", "nothing", "null", "call", "with", "taking", "for",
    "plus", "minus", "divided", "by", "mod", "modulo", "power", "floor",
    "increase", "decrease", "append", "remove", "ask",
    "add", "subtract", "multiply", "divide",
    "exit", "quit", "env", "clear", "help", "memory", "forget",
    "ops", "undo", "redo", "suggest", "teach", "stats", "sync",
]

# Regex: protect string literals from all transformations
_RE_STRINGS     = re.compile(r'"[^"\\]*(?:\\.[^"\\]*)*"|\'[^\'\\]*(?:\\.[^\'\\]*)*\'')
_RE_ALL_STRINGS = re.compile(r'f?"[^"\\]*(?:\\.[^"\\]*)*"|f?\'[^\'\\]*(?:\\.[^\'\\]*)*\'')
_STR_INTERP     = re.compile(r'"([^"]*\{[^}]+\}[^"]*)"')

# ── Abbreviation expansions (§2.8) ───────────────────────────────
_ABBREVIATIONS: list[tuple] = [
    (r"^var\s+(\w+)\s*=\s*(.+)$",      lambda m: f"set {m.group(1)} to {m.group(2)}"),
    (r"^let\s+(\w+)\s*=\s*(.+)$",      lambda m: f"set {m.group(1)} to {m.group(2)}"),
    (r"^const\s+(\w+)\s*=\s*(.+)$",    lambda m: f"set {m.group(1)} to {m.group(2)}"),
    (r"^echo\s+(.+)$",                  lambda m: f"say {m.group(1)}"),
    (r"^prompt\s+(\w+)\s+(.+)$",        lambda m: f"ask {m.group(1)} {m.group(2)}"),
    (r"^loop\s+(\d+)\s+times$",         lambda m: f"repeat {m.group(1)} times"),
    (r"^foreach\s+(\w+)\s+in\s+(.+)$", lambda m: f"for each {m.group(1)} in {m.group(2)}"),
]

# Common single-word typos corrected unconditionally (before anything else)
_WORD_TYPOS: dict[str, str] = {
    "too":   "to",    # set x too 10 → set x to 10
    "tto":   "to",
    "fo":    "to",
    "tymes": "times",
    "timez": "times",
    "bi":    "by",
    "bby":   "by",
    "iff":   "if",
    "sett":  "set",
    "saay":  "say",
    "ssy":   "say",
}

# ── Python-to-A++ translations ───────────────────────────────────
_PYTHON_TRANSLATIONS: list[tuple] = [
    (r"^print\((.+)\)$",               lambda m: f"say {m.group(1)}"),
    (r"^(\w+)\s*=\s*(.+)$",            lambda m: f"set {m.group(1)} to {m.group(2)}"),
    (r"^for\s+(\w+)\s+in\s+(.+):$",   lambda m: f"for each {m.group(1)} in {m.group(2)}"),
    (r"^def\s+(\w+)\s*\(([^)]*)\):$", lambda m: f"define {m.group(1)}"
               + (f" taking {m.group(2).strip()}" if m.group(2).strip() else "")),
    (r"^return\s+(.+)$",               lambda m: f"return {m.group(1)}"),
]

# ── Missing-keyword insertion rules (§2.2) ───────────────────────
# (broken_pattern, corrected_template_fn)
_MISSING_KW_RULES: list[tuple] = [
    # set x 10  →  set x to 10
    (r"^set\s+(\w+)\s+(?!to\b)(\S.*)$",
     lambda m: f"set {m.group(1)} to {m.group(2)}"),
    # increase health 5  →  increase health by 5
    (r"^(increase|decrease)\s+(\w+)\s+(\d+\S*)$",
     lambda m: f"{m.group(1)} {m.group(2)} by {m.group(3)}"),
    # append "apple" fruits  →  append "apple" to fruits
    (r'^append\s+(.+?)\s+(\w+)$',
     lambda m: f'append {m.group(1)} to {m.group(2)}'
               if "to" not in m.group(0).split() else None),
    # remove "apple" fruits  →  remove "apple" from fruits
    (r'^remove\s+(.+?)\s+(\w+)$',
     lambda m: f'remove {m.group(1)} from {m.group(2)}'
               if "from" not in m.group(0).split() else None),
    # repeat 5  →  repeat 5 times
    (r"^repeat\s+(\S+)\s*$",
     lambda m: f"repeat {m.group(1)} times"),
    # if x > 5  →  if x > 5 then
    (r"^(if\s+.+?)$",
     lambda m: m.group(1).strip() + " then"
               if not m.group(1).strip().lower().endswith("then") else None),
    # for each item list  →  for each item in list
    (r"^for\s+each\s+(\w+)\s+(?!in\b)(\w+)$",
     lambda m: f"for each {m.group(1)} in {m.group(2)}"),
    # define greet name  →  define greet taking name
    (r"^define\s+(\w+)\s+(?!taking\b)(\w+.*)$",
     lambda m: f"define {m.group(1)} taking {m.group(2)}"),
    # define greet(name)  →  define greet taking name
    (r"^define\s+(\w+)\s*\(([^)]*)\)$",
     lambda m: (f"define {m.group(1)} taking {m.group(2).strip()}"
                if m.group(2).strip() else f"define {m.group(1)}")),
    # print hello  →  say hello
    (r"^print\s+(?!\()(.+)$",
     lambda m: f"say {m.group(1)}"),
]

# ── Word-order transposition rules (§2.3) ────────────────────────
_TRANSPOSITION_RULES: list[tuple[str, str]] = [
    (r"^x\s+set\s+to\s+(.+)$",           r"set x to \1"),
    (r"^(\w+)\s+set\s+to\s+(.+)$",        r"set \1 to \2"),
    (r"^by\s+increase\s+(\w+)\s+(.+)$",   r"increase \1 by \2"),
    (r"^by\s+decrease\s+(\w+)\s+(.+)$",   r"decrease \1 by \2"),
    (r"^to\s+append\s+(.+?)\s+(\w+)$",    r"append \1 to \2"),
    (r"^times\s+repeat\s+(\S+)$",         r"repeat \1 times"),
    (r"^then\s+if\s+(.+)$",               r"if \1 then"),
]

# ── Extra-word removal rules (§2.4) ──────────────────────────────

# Only strip these unambiguous filler words (exclude 'a'/'an' — too risky as var names)
_NOISE_AFTER_KEYWORD = re.compile(
    r"^(set|increase|decrease|append|remove|say|call|define|ask|repeat|for|while|if)\s+"
    r"(the|my|our|new|old|some|out|just|please)\s+",
    re.IGNORECASE
)


def _strip_noise(line: str) -> str:
    """
    Remove a single unambiguous filler word directly after a command keyword.
    Only triggers on clearly non-identifier filler: the, my, our, new, old, some, out.
    Excluded: 'a', 'an' (too often used as variable names).
    """
    m = _NOISE_AFTER_KEYWORD.match(line)
    if m:
        keyword = m.group(1)
        rest    = line[m.end():]
        return keyword + " " + rest
    return line


# ── Merged-word splitting (§2.5) ──────────────────────────────────
def _try_split_merged(line: str) -> str | None:
    """
    If the line is a single token that looks like merged A++ keywords,
    try to identify the command prefix and split it.
    e.g. 'sayhello' → 'say hello',  'repeaat3times' → handled by fuzzy
    """
    if " " in line:
        return None   # already has spaces
    lw = line.lower()
    prefixes = [("say", "say "), ("set", "set "), ("repeat", "repeat "),
                ("increase", "increase "), ("decrease", "decrease "),
                ("append", "append "), ("remove", "remove "),
                ("define", "define "), ("return", "return "), ("call", "call ")]
    for kw, prefix in prefixes:
        if lw.startswith(kw) and len(lw) > len(kw):
            rest = line[len(kw):]
            return prefix + rest
    return None


def _timed_input(prompt: str, timeout: float = 8.0, default: str = "") -> str:
    """Input with timeout; returns default if time expires (non-interactive fallback)."""
    result = [default]
    done   = threading.Event()

    def _read():
        try:
            result[0] = input(prompt)
        except (EOFError, KeyboardInterrupt):
            result[0] = default
        finally:
            done.set()

    t = threading.Thread(target=_read, daemon=True)
    t.start()
    if not done.wait(timeout):
        print(f"\n  ⏱ (timeout — defaulting to '{default}')")
    return result[0]


def _pointer_line(line: str, start: int, length: int) -> str:
    """Return a '^' pointer under the indicated span."""
    return " " * start + "^" * max(1, length)


class IECE:
    """
    Intelligent Error Correction Engine  v3
    ─────────────────────────────────────────
    Pipeline (in order):
      1. normalize       — comments, memory recall, Python→A++, abbreviations
      2. split_merged    — detect accidentally merged words
      3. strip_noise     — remove filler words
      4. transpose       — detect swapped word order
      5. insert_keywords — detect and insert missing structural keywords
      6. fuzzy_correct   — word-level difflib correction (string-safe)
      7. var_correct      — runtime variable name suggestions
      8. phrase_correct  — multi-word edit-distance on 2-4 word phrases
    """

    def __init__(self) -> None:
        self.mem           = IECEMemory()
        self._session_rejected: set[str] = set()   # §2.7 session suppression

    # ── Step 1: normalize ────────────────────────────────────────

    def normalize(self, line: str) -> str:
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            return ""

        # Case-insensitive keyword matching (§2.9): lowercase only the first token
        words = line.split()
        words[0] = words[0].lower()
        line = " ".join(words)

        # Exact-line memory recall
        key = line.lower().strip()
        if key in self.mem:
            row = self.mem.get(key)
            if self.mem.high_confidence(key):
                _info(f"Auto-remembered: {line!r} → {row['right']!r}")
                return row["right"]
            # low confidence — still show
            _info(f"Remembered: {line!r} → {row['right']!r}")
            return row["right"]

        # Common single-word typos (unconditional, before anything else)
        words_lower = line.lower().split()
        corrected_words = [_WORD_TYPOS.get(w, w) if _WORD_TYPOS.get(w) else w
                           for w in line.split()]
        # Apply only to keyword-position words (preserve variable casing)
        rebuilt = []
        for orig_w in line.split():
            lw = orig_w.lower()
            if lw in _WORD_TYPOS:
                rebuilt.append(_WORD_TYPOS[lw])
            else:
                rebuilt.append(orig_w)
        line_fixed = " ".join(rebuilt)
        if line_fixed != line:
            _info(f"Typo-fix: {line!r} → {line_fixed!r}")
            line = line_fixed

        # Abbreviation expansions
        for pattern, replacement in _ABBREVIATIONS:
            m = re.match(pattern, line, re.IGNORECASE)
            if m:
                translated = replacement(m)
                if translated != line:
                    _info(f"Expanded: {line!r} → {translated!r}")
                return translated

        # Python-to-A++ translation
        for pattern, replacement in _PYTHON_TRANSLATIONS:
            m = re.match(pattern, line, re.IGNORECASE)
            if m:
                translated = replacement(m)
                if translated != line:
                    _info(f"Translated Python → A++: {line!r} → {translated!r}")
                return translated

        return line

    # ── Step 2: split merged words ───────────────────────────────

    def split_merged(self, line: str) -> str:
        split = _try_split_merged(line)
        if split and split != line:
            _info(f"Split merged words: {line!r} → {split!r}")
            return split
        return line

    # ── Step 3: strip noise words ────────────────────────────────

    def strip_noise(self, line: str) -> str:
        cleaned = _strip_noise(line)
        cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
        if cleaned != line:
            _info(f"Removed filler words: {line!r} → {cleaned!r}")
        return cleaned

    # ── Step 4: word-order transposition ─────────────────────────

    def transpose_correct(self, line: str) -> str:
        for pattern, replacement in _TRANSPOSITION_RULES:
            m = re.match(pattern, line, re.IGNORECASE)
            if m:
                fixed = re.sub(pattern, replacement, line, flags=re.IGNORECASE)
                if fixed != line:
                    _info(f"Word-order fix: {line!r} → {fixed!r}")
                    return fixed
        return line

    # ── Step 5: missing keyword insertion ────────────────────────

    def insert_keywords(self, line: str, interactive: bool) -> tuple[str, bool]:
        for pattern, fixer in _MISSING_KW_RULES:
            m = re.match(pattern, line, re.IGNORECASE)
            if not m:
                continue
            suggestion = fixer(m)
            if suggestion is None or suggestion.strip() == line.strip():
                continue

            session_key = f"kw:{line.lower().strip()}"
            if session_key in self._session_rejected:
                return line, True   # silently skip for this session

            if interactive:
                ans = _timed_input(
                    f"  💬 Did you mean:  {suggestion!r}  ? [Y/n]: "
                ).strip().lower()
                if ans != "n":
                    self.mem.learn(line, suggestion)
                    return suggestion, True
                else:
                    self._session_rejected.add(session_key)
                    return line, False
            else:
                _info(f"Keyword-insert: {line!r} → {suggestion!r}")
                return suggestion, True

        return line, True

    # ── Step 6: fuzzy word-level correction ──────────────────────

    def fuzzy_correct(self, line: str, context_vars: dict) -> str:
        vocab = _KEYWORDS + list(context_vars.keys())

        protected_zones = [(m.start(), m.end()) for m in _RE_STRINGS.finditer(line)]
        def in_protected(pos: int) -> bool:
            return any(s <= pos < e for s, e in protected_zones)

        words    = line.split()
        fixed    : list[str] = []
        changes  : list[str] = []
        char_pos = 0

        for w in words:
            wpos = line.find(w, char_pos)
            char_pos = wpos + len(w)

            skip = (
                in_protected(wpos)
                or any(c in w for c in ('"', "'", '[', ']', '{', '}', '(', ')'))
                or any(c.isdigit() for c in w)
            )
            if skip:
                fixed.append(w)
                continue

            clean = re.sub(r"[^a-zA-Z_]", "", w.lower())
            if not clean or clean in vocab:
                fixed.append(w)
                continue

            # Single-word memory recall
            if clean in self.mem and self.mem.high_confidence(clean):
                corrected = self.mem[clean]
                if corrected:
                    changes.append(f"{w} → {corrected}")
                    fixed.append(corrected)
                    continue

            # difflib fuzzy match
            matches = difflib.get_close_matches(clean, vocab, n=1, cutoff=0.88)
            if matches:
                m_word = matches[0]
                if len(clean) > len(m_word) + 2:   # false-positive guard
                    fixed.append(w)
                    continue
                corrected = re.sub(
                    re.escape(clean), m_word, w, count=1, flags=re.IGNORECASE
                )
                changes.append(f"{w} → {corrected}")
                fixed.append(corrected)
            else:
                fixed.append(w)

        if changes:
            _info("Fuzzy-correct: " + ",  ".join(changes))

        return " ".join(fixed)

    # ── Step 7: variable name suggestion ─────────────────────────

    def var_correct(self, line: str, context_vars: dict, interactive: bool,
                    lineno: int | None = None) -> tuple[str, bool]:
        """
        Check identifiers in the line against defined variables.
        If an unknown identifier is close to a known one, offer to substitute.
        """
        if not context_vars:
            return line, True

        # Find all bare identifiers (not inside strings, not keywords)
        protected_zones = [(m.start(), m.end()) for m in _RE_STRINGS.finditer(line)]
        def in_protected(pos: int) -> bool:
            return any(s <= pos < e for s, e in protected_zones)

        ident_re = re.compile(r'\b([a-zA-Z_]\w*)\b')
        replacements: list[tuple[str, int, int, str]] = []  # (orig, start, end, suggestion)

        for m in ident_re.finditer(line):
            if in_protected(m.start()):
                continue
            word = m.group(1)
            if word.lower() in _KEYWORDS:
                continue
            if word in context_vars:
                continue   # defined — fine

            candidates = difflib.get_close_matches(
                word, list(context_vars.keys()), n=1, cutoff=0.7
            )
            if candidates:
                replacements.append((word, m.start(), m.end(), candidates[0]))

        if not replacements:
            return line, True

        for orig, start, end, suggestion in replacements:
            session_key = f"var:{orig.lower()}"
            if session_key in self._session_rejected:
                continue

            if interactive:
                print(f"\n  ⚠️  Variable {orig!r} not defined.")
                print(f"  💡 Did you mean {suggestion!r}?")
                print(f"     {line}")
                print(f"     {_pointer_line(line, start, end - start)}")
                ans = _timed_input(f"  Correct {orig!r} → {suggestion!r}? [Y/n]: ").strip().lower()
                if ans != "n":
                    self.mem.learn(orig, suggestion, bump_confidence=15)
                    line = line[:start] + suggestion + line[end:]
                    _info(f"Variable corrected: {orig!r} → {suggestion!r}")
                else:
                    self._session_rejected.add(session_key)
                    self.mem.reject(orig)
                    _warn(f"Variable {orig!r} not defined  (line will likely fail at runtime)")
                    # Show pointer even on rejection
                    print(f"     {line}")
                    print(f"     {_pointer_line(line, start, end - start)}")
            else:
                _info(f"Variable auto-correct: {orig!r} → {suggestion!r}")
                line = line[:start] + suggestion + line[end:]

        return line, True

    # ── Step 8: multi-token phrase correction ─────────────────────

    def phrase_correct(self, line: str) -> str:
        """
        Whole-line template matching only — never touches sub-phrases of
        valid statements.  High-specificity patterns only.
        """
        WHOLE_LINE_FIXES = [
            (r"^insrease\s+(\w+)\s+bi\s+(.+)$",  r"increase \1 by \2"),
            (r"^repeet\s+(\S+)\s+tymes$",          r"repeat \1 times"),
            (r"^apend\s+(.+?)\s+too\s+(\w+)$",    r"append \1 to \2"),
            (r"^set\s+(\w+)\s+too\s+(.+)$",        r"set \1 to \2"),
        ]
        for pattern, replacement in WHOLE_LINE_FIXES:
            if re.match(pattern, line, re.IGNORECASE):
                fixed = re.sub(pattern, replacement, line, flags=re.IGNORECASE)
                if fixed != line:
                    _info(f"Phrase-correct: {line!r} → {fixed!r}")
                    return fixed
        return line

    # ── Full pipeline (called by interpreter) ────────────────────

    def process(self, line: str, context_vars: dict,
                interactive: bool, lineno: int | None = None) -> tuple[str, bool]:
        """
        Run all IECE steps in order.
        Returns (corrected_line, should_continue).
        """
        line = self.normalize(line)
        if not line:
            return "", True

        line = self.split_merged(line)
        line = self.strip_noise(line)
        line = self.transpose_correct(line)
        line, ok = self.insert_keywords(line, interactive)
        if not ok:
            return line, False

        line = self.fuzzy_correct(line, context_vars)
        line, ok = self.var_correct(line, context_vars, interactive, lineno)
        if not ok:
            return line, False

        line = self.phrase_correct(line)
        return line, True

    # ── Manual teach ─────────────────────────────────────────────

    def teach(self, wrong: str, right: str) -> None:
        self.mem.learn(wrong, right, bump_confidence=30)
        _info(f"Taught: {wrong!r} → {right!r}")


# ══════════════════════════════════════════════════════════════════
#  EXPRESSION TRANSPILER  (module-level, string-safe)
# ══════════════════════════════════════════════════════════════════

def _pythonify(expr: str) -> str:
    """
    Convert any A++ expression to valid Python.
    1. f-string conversion (before protection)
    2. Protect string literals
    3. Operator substitution
    4. Restore strings
    """
    expr = _STR_INTERP.sub(r'f"\1"', expr)

    _strings: dict[str, str] = {}
    _ctr = [0]

    def _protect(m: re.Match) -> str:
        key = f"\x00S{_ctr[0]}\x00"
        _strings[key] = m.group(0)
        _ctr[0] += 1
        return key

    protected = _RE_ALL_STRINGS.sub(_protect, expr)

    for eng, py_op in ALL_OPS:
        if not eng or eng == py_op:
            continue
        if eng[0].isalpha():
            protected = re.sub(
                r'\b' + re.escape(eng) + r'\b', py_op,
                protected, flags=re.IGNORECASE
            )
        else:
            protected = protected.replace(eng, py_op)

    for key, val in _strings.items():
        protected = protected.replace(key, val)

    return protected


# ══════════════════════════════════════════════════════════════════
#  SEMANTIC CHECKER
# ══════════════════════════════════════════════════════════════════

class SemanticChecker:
    _RE_STRING = re.compile(r"(['\"].*?['\"])")
    _RE_NUMBER = re.compile(r"\b\d+(\.\d+)?\b")
    _ARITH_OPS = ("+", "-", "*", "/", "%", "**")

    def check(self, lines: list[str]) -> bool:
        for i, py_line in enumerate(lines, start=1):
            m = re.match(r"^\s*\w+\s*=\s*(.*)", py_line)
            if not m:
                continue
            rhs       = m.group(1)
            has_str   = bool(self._RE_STRING.search(rhs))
            has_num   = bool(self._RE_NUMBER.search(rhs))
            has_arith = any(op in rhs for op in self._ARITH_OPS)
            if has_str and has_num and has_arith:
                _warn(f"Possible type mismatch on line {i}: "
                      "mixing string and number in arithmetic.")
                return False
        return True


# ══════════════════════════════════════════════════════════════════
#  PARSER
# ══════════════════════════════════════════════════════════════════

class Parser:
    def parse(self, line: str) -> tuple | None:
        s = line.strip()

        m = re.match(r"^set (.+?) to (.+)$", s, re.I)
        if m: return ("assign", m.group(1).strip(), m.group(2).strip())

        m = re.match(r"^increase (\w+) by (.+)$", s, re.I)
        if m: return ("augassign", m.group(1).strip(), "+", m.group(2).strip())

        m = re.match(r"^decrease (\w+) by (.+)$", s, re.I)
        if m: return ("augassign", m.group(1).strip(), "-", m.group(2).strip())

        m = re.match(r"^(add|subtract|multiply|divide|modulo)\s+(.+?)\s+(to|from|by)\s+(\w+)$", s, re.I)
        if m:
            op_map = {"add":"+","subtract":"-","multiply":"*","divide":"/","modulo":"%"}
            op = op_map[m.group(1).lower()]
            return ("augassign", m.group(4).strip(), op, m.group(2).strip())

        m = re.match(r"^say (.+)$", s, re.I)
        if m: return ("print", m.group(1).strip())

        m = re.match(r"^ask (\w+)\s+(.+)$", s, re.I)
        if m: return ("input", m.group(1).strip(), m.group(2).strip())

        m = re.match(r"^else if (.+?) then$", s, re.I)
        if m: return ("elif", m.group(1).strip())

        m = re.match(r"^if (.+?) then$", s, re.I)
        if m: return ("if", m.group(1).strip())

        if s.lower() == "else": return ("else",)

        m = re.match(r"^end\s+(if|loop|function)$", s, re.I)
        if m: return ("end", m.group(1).lower())

        m = re.match(r"^repeat (.+?) times$", s, re.I)
        if m: return ("loop", m.group(1).strip())

        m = re.match(r"^while (.+?)(?:\s+do)?$", s, re.I)
        if m: return ("while", m.group(1).strip())

        m = re.match(r"^for each (\w+) in (.+)$", s, re.I)
        if m: return ("foreach", m.group(1).strip(), m.group(2).strip())

        m = re.match(r"^define (\w+)(?:\s+taking\s+(.+))?$", s, re.I)
        if m:
            raw = m.group(2) or ""
            params = [p.strip() for p in re.split(r",\s*|\s+and\s+", raw) if p.strip()]
            return ("funcdef", m.group(1).strip(), params)

        m = re.match(r"^return\s*(.*)$", s, re.I)
        if m: return ("return", m.group(1).strip() or "None")

        m = re.match(r"^call (\w+)(?:\s+with\s+(.+))?$", s, re.I)
        if m:
            args_raw = m.group(2) or ""
            args = [a.strip() for a in re.split(r",\s*", args_raw) if a.strip()]
            return ("call", m.group(1).strip(), args)

        m = re.match(r"^append (.+?) to (\w+)$", s, re.I)
        if m: return ("append", m.group(1).strip(), m.group(2).strip())

        m = re.match(r"^remove (.+?) from (\w+)$", s, re.I)
        if m: return ("remove", m.group(1).strip(), m.group(2).strip())

        return None


# ══════════════════════════════════════════════════════════════════
#  TRANSPILER
# ══════════════════════════════════════════════════════════════════

class Transpiler:
    def to_python(self, node: tuple) -> tuple[str | None, str | None]:
        kind = node[0]

        if kind == "assign":      return f"{node[1]} = {_pythonify(node[2])}", "stmt"
        if kind == "augassign":   return f"{node[1]} {node[2]}= {_pythonify(node[3])}", "stmt"
        if kind == "print":       return f"print({_pythonify(node[1])})", "stmt"
        if kind == "input":       return f"{node[1]} = input({_pythonify(node[2])})", "stmt"
        if kind == "if":          return f"if {_pythonify(node[1])}:", "open_if"
        if kind == "elif":        return f"elif {_pythonify(node[1])}:", "elif"
        if kind == "else":        return "else:", "else"
        if kind == "end":         return f"# end {node[1]}", "close"
        if kind == "loop":        return f"for _ in range({_pythonify(node[1])}):", "open_loop"
        if kind == "while":       return f"while {_pythonify(node[1])}:", "open_loop"
        if kind == "foreach":     return f"for {node[1]} in {_pythonify(node[2])}:", "open_loop"
        if kind == "funcdef":
            params = ", ".join(node[2])
            return f"def {node[1]}({params}):", "open_func"
        if kind == "return":      return f"return {_pythonify(node[1])}", "stmt"
        if kind == "call":
            args = ", ".join(_pythonify(a) for a in node[2])
            return f"{node[1]}({args})", "stmt"
        if kind == "append":      return f"{node[2]}.append({_pythonify(node[1])})", "stmt"
        if kind == "remove":      return f"{node[2]}.remove({_pythonify(node[1])})", "stmt"

        return None, None


# ══════════════════════════════════════════════════════════════════
#  INTERPRETER
# ══════════════════════════════════════════════════════════════════

class AplusInterpreter:
    """
    Core A++ interpreter.
    Pipeline per line:  IECE v3 → Parser → Transpiler → SemanticChecker → exec()
    Extras: line numbers, undo/redo, suggest, teach, stats, sync.
    """

    def __init__(self) -> None:
        self.iece             = IECE()
        self.parser           = Parser()
        self.transpiler       = Transpiler()
        self.semantic_checker = SemanticChecker()

        self.env   : dict      = {}
        self.stack : list[str] = []
        self.buffer: list[str] = []

        # Line numbering
        self._repl_lineno : int = 0

        # Undo/redo stacks (store snapshots of env before each exec)
        self._undo_stack: deque[dict] = deque(maxlen=10)
        self._redo_stack: deque[dict] = deque(maxlen=10)

        # Last error for 'suggest' command
        self._last_failed_line: str = ""

        # Run decay on startup (background thread)
        threading.Thread(target=self.iece.mem.apply_decay, daemon=True).start()

    # ── single-line processor ────────────────────────────────────

    def process_line(self, line: str, lineno: int | None = None,
                     interactive: bool = False) -> bool:
        raw = line.strip()
        if not raw or raw.startswith("#") or raw.startswith("//"):
            return True

        # Full IECE pipeline
        line, ok = self.iece.process(raw, self.env, interactive, lineno)
        if not line:
            return True
        if not ok:
            self._last_failed_line = raw
            return True

        # Parse
        node = self.parser.parse(line)
        if not node:
            loc = f"line {lineno}: " if lineno else ""
            _err(f"{loc}Cannot parse: {line!r}")
            # Show pointer at the start of the line
            print(f"     {line}")
            print(f"     {'~' * len(line)}")
            print(f"  💡 Suggestions:")
            self._suggest_for(line)
            if interactive:
                _warn("Type 'help' for syntax examples.")
            self._last_failed_line = raw
            return False

        # Transpile
        py_code, action = self.transpiler.to_python(node)
        if not py_code:
            return True

        # Indentation
        indent = "    " * len(self.stack)
        if action == "close":
            if self.stack: self.stack.pop()
            indent = "    " * len(self.stack)
        elif action in ("else", "elif"):
            indent = "    " * (len(self.stack) - 1) if self.stack else ""

        self.buffer.append(indent + py_code)

        if   action == "open_if":   self.stack.append("if")
        elif action == "open_loop": self.stack.append("loop")
        elif action == "open_func": self.stack.append("func")

        # Execute when all blocks closed
        if not self.stack:
            code = "\n".join(self.buffer)
            self.buffer.clear()
            if code.strip():
                if self.semantic_checker.check(code.splitlines()):
                    self._snapshot_undo()
                    self._exec(code, lineno)
                else:
                    _err("Execution blocked: semantic error detected.")

        return True

    # ── REPL ─────────────────────────────────────────────────────

    def run(self) -> None:
        _print_banner()

        while True:
            try:
                # §1 — Line-numbered prompt
                self._repl_lineno += 1
                n = self._repl_lineno
                if self.stack:
                    prompt = f"A++[{n}]..> "
                else:
                    prompt = f"A++[{n}]> "
                raw = input(prompt)
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye! 👋")
                self.iece.mem.sync()
                break

            cmd = raw.strip().lower()

            if cmd in ("exit", "quit"):
                self.iece.mem.sync()
                print("Goodbye! 👋"); break

            if cmd == "env":
                self._show_env(); continue

            if cmd == "clear":
                self.env.clear(); self.buffer.clear(); self.stack.clear()
                self._repl_lineno = 0
                print("  ✅ Environment cleared."); continue

            if cmd == "help":
                _print_help(); continue

            if cmd == "ops":
                print(OPERATOR_REFERENCE); continue

            if cmd == "memory":
                self._show_memory(); continue

            if cmd == "forget":
                self.iece.mem.forget()
                print("  ✅ IECE memory wiped."); continue

            if cmd == "sync":
                self.iece.mem.sync()
                print("  ✅ Memory synced to disk."); continue

            if cmd == "stats":
                self._show_stats(); continue

            if cmd == "undo":
                self._do_undo(); continue

            if cmd == "redo":
                self._do_redo(); continue

            if cmd == "suggest":
                if self._last_failed_line:
                    print(f"  Suggestions for: {self._last_failed_line!r}")
                    self._suggest_for(self._last_failed_line)
                else:
                    print("  (no recent error to suggest for)")
                continue

            # teach wrong correct
            if cmd.startswith("teach "):
                parts = raw.strip().split(None, 2)
                if len(parts) == 3:
                    self.iece.teach(parts[1], parts[2])
                else:
                    _warn("Usage:  teach <wrong> <correct>")
                continue

            if not raw.strip():
                # blank line: don't increment the counter again next iteration
                self._repl_lineno -= 1
                if self.stack:
                    top = self.stack[-1]
                    _warn(f"Open block: '{top}'. Close with 'end {top}'.")
                continue

            self.process_line(raw, lineno=self._repl_lineno, interactive=True)

    # ── internals ────────────────────────────────────────────────

    def _exec(self, code: str, lineno: int | None = None) -> None:
        try:
            exec(compile(code, "<A++>", "exec"), self.env)
        except Exception as e:
            loc = f"near line {lineno} " if lineno else ""
            _warn(f"Runtime error {loc}→ {type(e).__name__}: {e}")
            if "--debug" in sys.argv:
                traceback.print_exc()

    def _snapshot_undo(self) -> None:
        """Save a shallow copy of env before execution for undo."""
        import copy
        self._undo_stack.append(copy.copy(self.env))
        self._redo_stack.clear()

    def _do_undo(self) -> None:
        if not self._undo_stack:
            print("  (nothing to undo)"); return
        import copy
        self._redo_stack.append(copy.copy(self.env))
        self.env.clear()
        self.env.update(self._undo_stack.pop())
        print("  ✅ Undone.")

    def _do_redo(self) -> None:
        if not self._redo_stack:
            print("  (nothing to redo)"); return
        import copy
        self._undo_stack.append(copy.copy(self.env))
        self.env.clear()
        self.env.update(self._redo_stack.pop())
        print("  ✅ Redone.")

    def _suggest_for(self, line: str) -> None:
        """Print human-readable correction suggestions for a failed line."""
        suggestions: list[str] = []

        # Check missing keywords
        for pattern, fixer in _MISSING_KW_RULES:
            m = re.match(pattern, line, re.IGNORECASE)
            if m:
                s = fixer(m)
                if s and s != line:
                    suggestions.append(f"Missing keyword fix → {s!r}")
                    break

        # Check fuzzy
        words = line.split()
        for w in words[:3]:
            clean = re.sub(r"[^a-zA-Z_]", "", w.lower())
            if not clean or clean in _KEYWORDS:
                continue
            matches = difflib.get_close_matches(clean, _KEYWORDS, n=1, cutoff=0.72)
            if matches:
                suggestions.append(f"Did you mean keyword {matches[0]!r} instead of {w!r}?")

        if not suggestions:
            suggestions.append("Check 'help' for correct syntax.")

        for s in suggestions:
            print(f"  • {s}")

    def _show_env(self) -> None:
        vs = {k: v for k, v in self.env.items()
              if not k.startswith("__") and not callable(v)}
        fs = [k for k, v in self.env.items()
              if callable(v) and not k.startswith("__")]
        if not vs and not fs:
            print("  (environment is empty)"); return
        if vs:
            print("  ── Variables ───────────────────────────────────")
            for k, v in sorted(vs.items()):
                print(f"    {k:22s} = {v!r}")
        if fs:
            print("  ── Functions ───────────────────────────────────")
            for f in sorted(fs):
                print(f"    {f}()")

    def _show_memory(self) -> None:
        rows = self.iece.mem.all_corrections()
        if not rows:
            print("  (IECE has no learned corrections yet)"); return
        print("  ── IECE Learned Corrections ────────────────────────")
        print(f"  {'WRONG':30s}  {'RIGHT':25s}  {'CONF':5}  {'USES':5}")
        print(f"  {'─'*30}  {'─'*25}  {'─'*5}  {'─'*5}")
        for r in rows:
            print(f"  {r['wrong']:30s}  {r['right']:25s}  {r['confidence']:5}  {r['use_count']:5}")

    def _show_stats(self) -> None:
        s = self.iece.mem.stats()
        print(f"""
  ── IECE Statistics ─────────────────────────────────
    Total corrections learned  : {s['total']}
    High-confidence (≥{_AUTO_THRESHOLD})      : {s['high_confidence']}
    Auto-save every N changes  : {_AUTO_SAVE_EVERY}
    Decay after (days)         : {_DECAY_DAYS}

  ── Top 5 Most-Used Corrections ─────────────────────""")
        for r in s["top5"]:
            print(f"    {r['wrong']:25s} → {r['right']:20s}  ({r['use_count']} uses)")


# ══════════════════════════════════════════════════════════════════
#  FILE RUNNER
# ══════════════════════════════════════════════════════════════════

def run_file(filename: str) -> None:
    interp = AplusInterpreter()

    try:
        with open(filename, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        _err(f"File '{filename}' not found."); sys.exit(1)
    except OSError as e:
        _err(f"Could not read '{filename}': {e}"); sys.exit(1)

    last = 1
    for lineno, raw in enumerate(lines, start=1):
        last = lineno
        interp.process_line(raw, lineno=lineno, interactive=False)

    if interp.buffer:
        code = "\n".join(interp.buffer)
        if code.strip():
            if interp.semantic_checker.check(code.splitlines()):
                interp._exec(code, lineno=last)
            else:
                _err("Execution blocked: semantic error in final block.")
    elif interp.stack:
        _warn(f"File ended with unclosed block(s): {interp.stack}")

    interp.iece.mem.sync()


# ══════════════════════════════════════════════════════════════════
#  BANNER  &  HELP
# ══════════════════════════════════════════════════════════════════

def _print_banner() -> None:
    print("""
  ╔══════════════════════════════════════════════════════════════╗
  ║                                                              ║
  ║          A++  —  Plain-English Programming Language          ║
  ║                                                              ║
  ║   Version   :  0.6  Prototype                                ║
  ║   Started   :  21 / 04 / 2026                                ║
  ║   Updated   :  22 / 04 / 2026                                ║
  ║                                                              ║
  ║   "Code in the language you already speak."                  ║
  ║                                                              ║
  ╠══════════════════════════════════════════════════════════════╣
  ║   IECE v3  —  What's new                                     ║
  ║   ─────────────────────────────────────────────────────────  ║
  ║   • Numbered prompts  A++[1]>  A++[2]..>                     ║
  ║   • Missing keyword insertion  (set x 10 → set x to 10)      ║
  ║   • Word-order transposition   (x set to → set x to)         ║
  ║   • Filler-word removal        (set the x → set x)           ║
  ║   • Merged-word splitting      (sayhello → say hello)        ║
  ║   • Variable name suggestions  with ^ pointer                 ║
  ║   • Multi-token phrase correction                             ║
  ║   • Abbreviations: var/let/const/echo/prompt/foreach/loop     ║
  ║   • SQLite memory with confidence & decay                     ║
  ║   • undo / redo  (last 10 states)                             ║
  ╠══════════════════════════════════════════════════════════════╣
  ║   REPL Commands                                              ║
  ║   ─────────────────────────────────────────────────────────  ║
  ║   help    syntax reference          ops      operator table  ║
  ║   env     variables & functions     memory   corrections     ║
  ║   stats   IECE statistics           sync     save to disk    ║
  ║   undo    undo last change          redo     redo            ║
  ║   suggest corrections for last err  forget   wipe memory     ║
  ║   teach <wrong> <correct>           clear    reset env       ║
  ║   exit    quit                                               ║
  ╚══════════════════════════════════════════════════════════════╝
""")


def _print_help() -> None:
    print("""
  ── ASSIGNMENT ─────────────────────────────────────────────────
    set x to 10
    set name to "Anand"
    set result to x plus 5        (English arithmetic)
    set result to x + 5           (symbolic arithmetic)
    increase score by 5           →  score += 5
    decrease health by 1          →  health -= 1
    add 3 to total                →  total += 3
    subtract 2 from total         →  total -= 2

  ── OUTPUT / INPUT ─────────────────────────────────────────────
    say "Hello, {name}!"          (auto f-string)
    ask age "How old are you? "   →  age = input(…)

  ── ABBREVIATIONS (auto-expanded) ──────────────────────────────
    var x = 10   let x = 10   const x = 10  →  set x to 10
    echo "hi"    print "hi"                 →  say "hi"
    prompt age "…"                           →  ask age "…"
    loop 5 times                             →  repeat 5 times
    foreach item in list                     →  for each item in list

  ── CONDITIONALS ───────────────────────────────────────────────
    if x is greater than 5 then
      say "big"
    else if x == 5 then
      say "five"
    else
      say "small"
    end if

  ── LOOPS ──────────────────────────────────────────────────────
    repeat 3 times / while x < 10 / for each item in fruits
    …body…
    end loop

  ── FUNCTIONS ──────────────────────────────────────────────────
    define greet taking name
      say "Hello, {name}!"
    end function
    call greet with "Anand"

  ── LISTS ──────────────────────────────────────────────────────
    set fruits to ["apple", "mango"]
    append "kiwi" to fruits
    remove "apple" from fruits

  ── IECE v3 COMMANDS ───────────────────────────────────────────
    undo              undo last execution
    redo              redo last undone execution
    suggest           show corrections for last error
    teach bad good    manually add correction to memory
    stats             IECE statistics (memory, confidence, top corrections)
    memory            list all learned corrections
    forget            wipe IECE memory
    sync              force save memory to disk
    ops               full operator table
""")


# ══════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    file_args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if file_args:
        run_file(file_args[0])
    else:
        AplusInterpreter().run()
